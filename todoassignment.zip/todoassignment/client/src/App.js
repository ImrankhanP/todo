import React, { Component } from 'react';
import axios from 'axios';
import './App.css';



class App extends Component {

  state = { todo: [] }

  async componentDidMount() {
    var response = await axios('http://localhost:3001')
    this.setState({ todo: response.data.todoslist })
  }

  renderList() {
    return this.state.todo.map((item, index) => {
      return (
        <div className="box" key={index}>
          <div style={{marginBottom : '10px'}}>
            <span className="dot"></span>
            <text style={{fontSize:20}}>Do</text>
            <span className="date">
            {new Date().getDate() + '/ '   + new Date().getMonth() + '/' + new Date().getFullYear()}
            </span>
          </div>
          <div style={{marginLeft : 20}} >
          {item}
          </div>
        </div>
      )
    }
    )
  }



  render() {
    return (
      <div>
        {this.renderList()}
      </div>
    );
  }
}


export default App;