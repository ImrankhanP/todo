var fs = require('fs');
var express = require('express')
var app = express()
var cors = require('cors');

app.use(cors())



app.get("/", function(req, res) {
    fs.readFile('data.json', 'utf8', function (err, data) {
      if (err) throw err;
       let dbData = JSON.parse(data);
       res.send(dbData);
  
    });
  })

 

app.listen(3001)

